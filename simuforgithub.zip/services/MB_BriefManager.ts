
import { MB_MasterBrief, MB_BriefVersion } from '../types';
import { generateId, MB_saveBrief, MB_deleteBrief, MB_getBriefs } from './storageService';

export class MB_BriefManager {
  
  static getAll(): MB_MasterBrief[] {
    return MB_getBriefs();
  }

  static create(
    title: string, 
    content: string, 
    folder: any = 'Advertising', 
    subFolder: string = 'Text',
    images: string[] = []
  ): MB_MasterBrief {
    const newBrief: MB_MasterBrief = {
      id: generateId(),
      mb_title: title,
      mb_content: content,
      mb_type: 'Marketing',
      mb_folder: folder,
      mb_subFolder: subFolder,
      mb_versions: [],
      mb_images: images,
      createdAt: Date.now()
    };
    MB_saveBrief(newBrief);
    return newBrief;
  }

  static update(brief: MB_MasterBrief, updates: Partial<MB_MasterBrief>): MB_MasterBrief {
    const updated = { ...brief, ...updates };
    MB_saveBrief(updated);
    return updated;
  }

  static createVersion(brief: MB_MasterBrief): MB_MasterBrief {
    const newVersion: MB_BriefVersion = {
      id: generateId(),
      label: `v${(brief.mb_versions?.length || 0) + 1}`,
      content: brief.mb_content,
      createdAt: Date.now()
    };
    const updated = {
      ...brief,
      mb_versions: [...(brief.mb_versions || []), newVersion]
    };
    MB_saveBrief(updated);
    return updated;
  }

  static delete(id: string) {
    MB_deleteBrief(id);
  }
}
