
import { Session, MB_MasterBrief, AS_AudienceCohort, Article, AS_Persona, AS_MarketStat, AS_CohortArchetype, AS_GroupOverview } from '../types';

const MB_STORAGE_KEY = 'MB_store_v1';
const AS_STORAGE_KEY = 'AS_store_v1';
const SESSION_KEY = 'simucrowd_sessions_v2';
const ARTICLE_KEY = 'simucrowd_articles_v1';

// --- UTILITIES ---
export const generateId = (): string => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'id_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
};

// --- DYNAMIC ARCHETYPE GENERATOR ---
const generateArchetypes = (category: string): AS_CohortArchetype[] => {
  
  // 1. BEAUTY & WELLNESS
  if (category.includes('Beauty')) {
    return [
      {
        id: 'arch_beauty_1', type: 'HAPPY_PATH',
        name: 'Chloe Chen (26)', role: 'Skincare Enthusiast', age: 26,
        tags: ['#VisualLearner', '#IngredientAware', '#ImpulseReady'],
        context: "Follows derms on TikTok. Ready to buy instantly if the 'glow' looks real and packaging is aesthetic.",
        decisionWeights: { price: 'Low', brand: 'High', social: 'High', function: 'Medium' },
        adResistance: 'Low', adResistanceReason: "Low: actively consumes ads as discovery content.",
        cognitiveLoadPreference: "Quick visual proof",
        triggers: ["'Viral' label", "Before/After video", "Aesthetic packaging"],
        frictions: ["Ugly branding", "Too much text"],
        switchingCost: "Low - loves novelty",
        difficultyRating: 'Easy', difficultyReason: "High intent, seeks novelty.",
        decisionPath: "See TikTok → Check Comments → Buy",
        aiStrategyTip: "Lead with texture shots and immediate visual payoff."
      },
      {
        id: 'arch_beauty_2', type: 'BASELINE',
        name: 'Linda Wang (34)', role: 'Routine Pragmatist', age: 34,
        tags: ['#RoutineOriented', '#ReviewChecker', '#Cautious'],
        context: "Has a stable routine. Needs a very good reason to swap out her moisturizer. Checks Incidecoder.",
        decisionWeights: { price: 'Medium', brand: 'Medium', social: 'High', function: 'High' },
        adResistance: 'Medium', adResistanceReason: "Medium: Filters out 'miracle' claims.",
        cognitiveLoadPreference: "Ingredient highlighting",
        triggers: ["Dermatologist stamp", "Fragrance-free", "Clinical results"],
        frictions: ["Subscription only", "Vague ingredient list"],
        switchingCost: "Medium - fear of breakouts",
        difficultyRating: 'Moderate', difficultyReason: "Needs trust validation.",
        decisionPath: "Ad → Influencer Review → Website → Cart",
        aiStrategyTip: "Focus on safety, clinical backing, and ease of integration."
      },
      {
        id: 'arch_beauty_3', type: 'STRESS_TEST',
        name: 'Elena K. (42)', role: 'Ingredient Purist', age: 42,
        tags: ['#Skeptic', '#CleanBeauty', '#Loyalist'],
        context: "Believes most industry marketing is a lie. Only trusts medical-grade or strictly clean brands.",
        decisionWeights: { price: 'High', brand: 'Low', social: 'Low', function: 'High' },
        adResistance: 'High', adResistanceReason: "High: Ignores glossy ads, reads labels only.",
        cognitiveLoadPreference: "Deep technical dive",
        triggers: ["Peer-reviewed study", "Sample kit", "Founder story"],
        frictions: ["Perfume/Parfum", "Flashy claims", "Influencers"],
        switchingCost: "High",
        difficultyRating: 'Hard', difficultyReason: "Active distrust of marketing.",
        decisionPath: "Ad → Ignore → Read Forum → Sample",
        aiStrategyTip: "Avoid 'selling'. Use educational long-form content."
      }
    ];
  }

  // 2. AUTOMOTIVE
  if (category.includes('Automotive')) {
    return [
      {
        id: 'arch_auto_1', type: 'HAPPY_PATH',
        name: 'Mike Ross (34)', role: 'Tech Early Adopter', age: 34,
        tags: ['#SpecHunter', '#EVReady', '#Status'],
        context: "Wants the Tesla killer. Cares about screen size, 0-60, and autonomous features.",
        decisionWeights: { price: 'Medium', brand: 'High', social: 'High', function: 'High' },
        adResistance: 'Low', adResistanceReason: "Low for tech specs, High for lifestyle fluff.",
        cognitiveLoadPreference: "Specs table comparison",
        triggers: ["New Tech Reveal", "Range breakthrough", "OS Update"],
        frictions: ["Legacy dealer network", "Outdated UI"],
        switchingCost: "Medium",
        difficultyRating: 'Easy', difficultyReason: "Actively looking for upgrades.",
        decisionPath: "Video Review → Configurator → Test Drive",
        aiStrategyTip: "Highlight software, connectivity, and performance metrics."
      },
      {
        id: 'arch_auto_2', type: 'BASELINE',
        name: 'David Chen (40)', role: 'Family Pragmatist', age: 40,
        tags: ['#SafetyFirst', '#Value', '#Resale'],
        context: "Needs a daily driver that fits 2 kids and a dog. Worried about repair costs and resale value.",
        decisionWeights: { price: 'High', brand: 'Medium', social: 'Medium', function: 'High' },
        adResistance: 'Medium', adResistanceReason: "Medium: Needs practical demonstration.",
        cognitiveLoadPreference: "Safety ratings & Cargo space",
        triggers: ["0% APR", "Top Safety Pick", "Warranty"],
        frictions: ["Range anxiety", "Hidden fees"],
        switchingCost: "High",
        difficultyRating: 'Moderate', difficultyReason: "Risk averse purchase.",
        decisionPath: "Research → Spreadsheet → Dealer Visit",
        aiStrategyTip: "Focus on TCO (Total Cost of Ownership), safety, and space."
      },
      {
        id: 'arch_auto_3', type: 'STRESS_TEST',
        name: 'Marcus T. (55)', role: 'Combustion Loyalist', age: 55,
        tags: ['#PetrolHead', '#Skeptic', '#Tradition'],
        context: "Thinks EVs are a scam/toy. Trusts mechanical engineering, hates touchscreens.",
        decisionWeights: { price: 'Medium', brand: 'High', social: 'Low', function: 'High' },
        adResistance: 'High', adResistanceReason: "High: Rejects 'green' messaging.",
        cognitiveLoadPreference: "Mechanical details",
        triggers: ["Build quality", "Physical buttons", "Range proof"],
        frictions: ["Charging time", "Software reliance"],
        switchingCost: "Very High",
        difficultyRating: 'Hard', difficultyReason: "Ideological resistance.",
        decisionPath: "Ad → Dismiss → Peer Validation → Test Drive",
        aiStrategyTip: "Don't sell 'Eco'. Sell 'Performance' and 'Independence'."
      }
    ];
  }

  // 3. REAL ESTATE
  if (category.includes('Real Estate')) {
    return [
      {
        id: 'arch_home_1', type: 'HAPPY_PATH',
        name: 'Sarah & Tom (30)', role: 'Lifestyle Upgraders', age: 30,
        tags: ['#Aesthetic', '#Turnkey', '#DINK'],
        context: "Dual income, no kids yet. Want a 'Pinterest-ready' home to entertain friends.",
        decisionWeights: { price: 'Medium', brand: 'High', social: 'High', function: 'Medium' },
        adResistance: 'Low', adResistanceReason: "Low: Highly susceptible to staging/visuals.",
        cognitiveLoadPreference: "Visual tour",
        triggers: ["Open concept", "Modern finishes", "Smart home"],
        frictions: ["Renovation needed", "Bad neighborhood vibe"],
        switchingCost: "High",
        difficultyRating: 'Easy', difficultyReason: "Emotional buyers.",
        decisionPath: "Zillow → Instagram → Viewing",
        aiStrategyTip: "Sell the 'Sunday Morning' lifestyle vision, not just square footage."
      },
      {
        id: 'arch_home_2', type: 'BASELINE',
        name: 'Raj Patel (38)', role: 'Investment Minded', age: 38,
        tags: ['#ROI', '#SchoolDistrict', '#FutureProof'],
        context: "Buying for the next 10 years. Cares about school ratings and appreciation potential.",
        decisionWeights: { price: 'High', brand: 'Low', social: 'Medium', function: 'High' },
        adResistance: 'Medium', adResistanceReason: "Medium: Validates claims with data.",
        cognitiveLoadPreference: "Market comps & data",
        triggers: ["Undervalued", "Great Schools", "Up-and-coming area"],
        frictions: ["HOA fees", "Market peak fears"],
        switchingCost: "Very High",
        difficultyRating: 'Moderate', difficultyReason: "Analytical paralysis.",
        decisionPath: "Data Analysis → Agent Chat → Inspection",
        aiStrategyTip: "Provide market data, growth projections, and detailed floorplans."
      },
      {
        id: 'arch_home_3', type: 'STRESS_TEST',
        name: 'Karen B. (50)', role: 'Risk-Averse Downsizer', age: 50,
        tags: ['#Safety', '#LowMaintenance', '#Skeptic'],
        context: "Leaving a family home. Terrified of buying a 'lemon' or noisy neighbors.",
        decisionWeights: { price: 'Medium', brand: 'High', social: 'High', function: 'High' },
        adResistance: 'High', adResistanceReason: "High: Fears scams and hidden issues.",
        cognitiveLoadPreference: "Detailed disclosures",
        triggers: ["Warranty", "Quiet neighborhood", "Single story"],
        frictions: ["High taxes", "Busy street", "Pressure tactics"],
        switchingCost: "Extreme",
        difficultyRating: 'Hard', difficultyReason: "Emotional attachment to past.",
        decisionPath: "Browsing → Doubt → Family Council → Viewing",
        aiStrategyTip: "Emphasize security, community quality, and low maintenance."
      }
    ];
  }

  // DEFAULT / OTHER
  return [
    {
      id: 'arch_base_1', type: 'HAPPY_PATH',
      name: 'Sarah Jenkins (29)', role: 'Brand Advocate', age: 29,
      tags: ['#ImpulseBuy', '#BrandLover', '#EarlyAdopter'],
      context: "Actively looking for the newest upgrade, prioritizes specs over price.",
      decisionWeights: { price: 'Low', brand: 'High', social: 'High', function: 'Medium' },
      adResistance: 'Low', adResistanceReason: "Very Low: Actively seeks out new product ads.",
      cognitiveLoadPreference: "Quick emotional stimuli",
      triggers: ["Influencer mention", "Limited Edition tag"],
      frictions: ["Out of stock", "Slow shipping"],
      switchingCost: "Low",
      difficultyRating: 'Easy', difficultyReason: "High intent.",
      decisionPath: "See Ad → Instant Buy",
      aiStrategyTip: "Target with high-energy visuals."
    },
    {
      id: 'arch_base_2', type: 'BASELINE',
      name: 'Alex Mercer (35)', role: 'Value Maximizer', age: 35,
      tags: ['#PriceSensitive', '#ResearchOriented', '#Cautious'],
      context: "Needs a reliable solution, compares 3-4 options before committing.",
      decisionWeights: { price: 'Medium', brand: 'Medium', social: 'High', function: 'High' },
      adResistance: 'Medium', adResistanceReason: "Medium: Filters out 'salesy' ads.",
      cognitiveLoadPreference: "Rational comparison",
      triggers: ["Social proof", "Discount"],
      frictions: ["Hidden fees", "Confusing claims"],
      switchingCost: "Moderate",
      difficultyRating: 'Moderate', difficultyReason: "Logical validation.",
      decisionPath: "Sees Ad → Reviews → Compares Price → Buys",
      aiStrategyTip: "Lead with education and social proof."
    },
    {
      id: 'arch_base_3', type: 'STRESS_TEST',
      name: 'Karen B. (48)', role: 'Category Skeptic', age: 48,
      tags: ['#AdImmune', '#RiskAverse', '#Loyalist'],
      context: "Hates change. Believes 'they don't make them like they used to'.",
      decisionWeights: { price: 'High', brand: 'Low', social: 'Low', function: 'High' },
      adResistance: 'High', adResistanceReason: "High: Needs authority endorsement.",
      cognitiveLoadPreference: "Deep technical analysis",
      triggers: ["Money-back guarantee", "Risk reversal"],
      frictions: ["Marketing fluff", "New brand"],
      switchingCost: "High",
      difficultyRating: 'Hard', difficultyReason: "Active resistance.",
      decisionPath: "Sees Ad → Ignores → Investigates deeply → Maybe Tries",
      aiStrategyTip: "Use whitepapers, sampling, and risk-free trials."
    }
  ];
};

const generateGroupOverview = (category: string, total: number): AS_GroupOverview => {
  let characteristics = "A mix of diverse ages and backgrounds with varying degrees of digital adoption.";
  let dist = { happyPath: 20, baseline: 60, stressTest: 20 };
  let visualHint = "Ad Resistance: Low → High, Decision Speed: Fast → Slow";

  if (category.includes('Beauty')) {
    characteristics = "Visual-first, skincare-aware demographic. High engagement with influencer content but skeptical of 'miracle' claims. Price sensitivity is moderate, but ingredient quality is paramount.";
    dist = { happyPath: 25, baseline: 55, stressTest: 20 };
    visualHint = "Ad Resistance varies by ingredient knowledge. High impulse potential.";
  } else if (category.includes('Automotive')) {
    characteristics = "Pragmatic, research-heavy buyers. High concern for safety, resale value, and technical specs. Skepticism towards new EV brands is a common friction point.";
    dist = { happyPath: 15, baseline: 65, stressTest: 20 };
    visualHint = "Decision Speed: Slow. Research Phase: Long.";
  } else if (category.includes('Real Estate')) {
    characteristics = "Risk-averse, life-stage driven buyers. Emotional attachment clashes with budget constraints. High need for trust and visual verification.";
    dist = { happyPath: 10, baseline: 60, stressTest: 30 };
    visualHint = "High Friction due to cost. Requires trust signals.";
  } else if (category.includes('Gen-Z')) {
    characteristics = "Digital natives, highly trend-responsive. Extremely short attention spans and high BS-detector for corporate marketing. Values authenticity over polish.";
    dist = { happyPath: 30, baseline: 40, stressTest: 30 };
    visualHint = "Ad Resistance: Very High for traditional ads, Low for native content.";
  }

  return {
    totalUsers: total,
    characteristics,
    distribution: dist,
    visualHint
  };
};

// --- MODULE A: MASTER BRIEFS STORAGE ---

export const MB_getBriefs = (): MB_MasterBrief[] => {
  try {
    const stored = localStorage.getItem(MB_STORAGE_KEY);
    if (stored) {
       return JSON.parse(stored);
    }
    return MB_INITIAL_BRIEFS;
  } catch (e) {
    console.error("MB_Storage Error:", e);
    return MB_INITIAL_BRIEFS;
  }
};

export const MB_saveBrief = (brief: MB_MasterBrief): void => {
  try {
    const briefs = MB_getBriefs();
    const index = briefs.findIndex(b => b.id === brief.id);
    if (index >= 0) briefs[index] = brief;
    else briefs.unshift(brief);
    localStorage.setItem(MB_STORAGE_KEY, JSON.stringify(briefs));
  } catch (e) { console.error(e); }
};

export const MB_deleteBrief = (id: string): void => {
  try {
    const briefs = MB_getBriefs().filter(b => b.id !== id);
    localStorage.setItem(MB_STORAGE_KEY, JSON.stringify(briefs));
  } catch (e) { console.error(e); }
};

// --- MODULE B: AUDIENCE SIMULATOR STORAGE ---

export const AS_getCohorts = (): AS_AudienceCohort[] => {
  try {
    const stored = localStorage.getItem(AS_STORAGE_KEY);
    const customCohorts: AS_AudienceCohort[] = stored ? JSON.parse(stored) : [];
    
    // Deduplicate based on ID to ensure officials are always present but overridable
    const customIds = new Set(customCohorts.map(c => c.id));
    const activeOfficials = AS_OFFICIAL_COHORTS.filter(c => !customIds.has(c.id));
    
    return [...activeOfficials, ...customCohorts];
  } catch (e) {
    console.error("AS_Storage Error:", e);
    return [...AS_OFFICIAL_COHORTS];
  }
};

export const AS_saveCohort = (cohort: AS_AudienceCohort): void => {
  try {
    const stored = localStorage.getItem(AS_STORAGE_KEY);
    let customCohorts: AS_AudienceCohort[] = stored ? JSON.parse(stored) : [];
    
    const index = customCohorts.findIndex(c => c.id === cohort.id);
    if (index >= 0) customCohorts[index] = cohort;
    else customCohorts.unshift(cohort);
    
    localStorage.setItem(AS_STORAGE_KEY, JSON.stringify(customCohorts));
  } catch (e) { console.error(e); }
};

export const AS_deleteCohort = (id: string): void => {
  try {
    const stored = localStorage.getItem(AS_STORAGE_KEY);
    if (!stored) return;
    const customCohorts: AS_AudienceCohort[] = JSON.parse(stored);
    const filtered = customCohorts.filter(c => c.id !== id);
    localStorage.setItem(AS_STORAGE_KEY, JSON.stringify(filtered));
  } catch (e) { console.error(e); }
};

// --- SESSION & ARTICLE (SHARED) ---

export const getSessions = (): Session[] => {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY) || '[]'); } catch (e) { return []; }
};

export const saveSession = (session: Session): void => {
  const sessions = getSessions();
  const index = sessions.findIndex(s => s.id === session.id);
  if (index >= 0) sessions[index] = session;
  else sessions.unshift(session);
  localStorage.setItem(SESSION_KEY, JSON.stringify(sessions));
};

export const deleteSession = (id: string): Session[] => {
  const sessions = getSessions().filter(s => s.id !== id);
  localStorage.setItem(SESSION_KEY, JSON.stringify(sessions));
  return sessions;
};

export const getArticles = (): Article[] => {
  try { return JSON.parse(localStorage.getItem(ARTICLE_KEY) || '[]'); } catch { return []; }
};

export const saveArticle = (article: Article): void => {
  const articles = getArticles();
  const index = articles.findIndex(a => a.id === article.id);
  if (index >= 0) articles[index] = article;
  else articles.unshift(article);
  localStorage.setItem(ARTICLE_KEY, JSON.stringify(articles));
};

// --- INITIAL DATA FACTORIES ---

// 1. Brief Factory
const createBrief = (
  id: string,
  folder: 'Advertising' | 'Internet' | 'Ecommerce' | 'Subscription' | 'Brand',
  subFolder: string,
  title: string,
  question: string,
  description: string,
  variables: string,
  metrics: string
): MB_MasterBrief => ({
  id,
  mb_title: title,
  mb_content: `**Core Question:** ${question}\n\n**Description:** ${description}\n\n**Variables:** ${variables}\n**Metrics:** ${metrics}`,
  mb_type: 'Marketing',
  mb_folder: folder,
  mb_subFolder: subFolder,
  mb_tags: [subFolder, ...variables.split(', ').slice(0,2)],
  createdAt: Date.now(),
  mb_versions: []
});

const MB_INITIAL_BRIEFS: MB_MasterBrief[] = [
  // ADVERTISING
  createBrief('adv_1', 'Advertising', 'Creative Hook', '3-Second Hook Audit', 'Will people stop scrolling right away?', 'Check if users get hooked instantly or just swipe past', 'Emotional vs Functional hook, High vs Low conflict', 'Thumbstop Rate / 3s View Rate'),
  createBrief('adv_2', 'Advertising', 'Creative Hook', 'Multi-Hook A/B Test', 'Which opening scales best?', 'Same ad, different openings, see which one performs', 'Hook intensity levels', 'CTR / CPM'),
  createBrief('adv_3', 'Advertising', 'Visual', 'Visual Attention Test', 'Where does the eye go first?', 'See if the visual focus is clear or too messy', 'Subject size / Contrast / Visual flow', 'View Rate'),
  createBrief('adv_4', 'Advertising', 'Copy', 'Headline Stress Test', 'Can people understand it at a glance?', 'Test if the message is clear on first read', 'Emotional vs Functional wording', 'CTR'),
  createBrief('adv_5', 'Advertising', 'CTA', 'CTA Impact Test', 'Will people actually click?', 'Check if the ending pushes users to act', 'Strong vs Weak CTA', 'CVR'),

  // INTERNET / APP
  createBrief('int_1', 'Internet', 'Onboarding', 'First Screen Clarity', 'Do users instantly get what this app does?', 'See if the value is obvious when the app opens', 'Single value prop vs Multiple', 'Bounce Rate'),
  createBrief('int_2', 'Internet', 'Onboarding', 'Onboarding Drop-off', 'Where do new users give up?', 'Find the step that scares users away', 'Fewer steps', 'Completion Rate'),
  createBrief('int_3', 'Internet', 'Feature', 'Feature Value Test', 'Do users think this feature is useful?', 'Test if users actually want to use it', 'Scenario-led vs Feature-led', 'Feature Adoption'),
  createBrief('int_4', 'Internet', 'UX', 'Cognitive Load Test', 'Does this feel confusing to use?', 'See if users have to think too hard', 'Simpler copy', 'Time to Action'),

  // E-COMMERCE
  createBrief('ecom_1', 'Ecommerce', 'PDP', 'PDP Conversion Audit', 'Does this product make people want to buy?', 'Check if the product page sells the value well', 'Reorder product info', 'PDP CVR'),
  createBrief('ecom_2', 'Ecommerce', 'PDP', 'Image Trust Test', 'Do the images feel trustworthy?', 'Test if visuals feel real or over-edited', 'UGC vs Official images', 'CVR'),
  createBrief('ecom_3', 'Ecommerce', 'Pricing', 'Price Anchor Test', 'Does the price feel expensive?', 'See if price comparison changes perception', 'Original price framing', 'AOV'),
  createBrief('ecom_4', 'Ecommerce', 'Promotion', 'Promo Framing Test', 'Do people notice the discount?', 'Check if users even realize there’s a deal', '% off vs $ off', 'CTR / CVR'),
  createBrief('ecom_5', 'Ecommerce', 'Checkout', 'Checkout Friction Test', 'Why didn’t they finish paying?', 'Find what makes checkout annoying', 'Reduce form fields', 'Checkout Completion'),

  // SUBSCRIPTION
  createBrief('sub_1', 'Subscription', 'Paywall', 'Paywall Strategy Test', 'Is this paywall showing up too early?', 'Test when and how to block users', 'Trigger timing', 'Paid CVR'),
  createBrief('sub_2', 'Subscription', 'Pricing', 'Pricing Sensitivity Test', 'How much are users willing to pay?', 'See when price becomes a deal-breaker', 'Weekly vs Annual plans', 'ARPU'),
  createBrief('sub_3', 'Subscription', 'Packaging', 'Value Packaging Test', 'Do users understand what they’re buying?', 'Test if benefits are clear or confusing', 'Feature-based vs Outcome-based', 'Take Rate'),
  createBrief('sub_4', 'Subscription', 'Retention', 'Trial to Paid Test', 'Will users pay after trying it?', 'Check if the trial feels worth it', 'Trial length', 'Trial CVR'),
  createBrief('sub_5', 'Subscription', 'Monetization', 'IAP Hook Test', 'Will users buy on impulse?', 'See if timing and wording trigger impulse buys', 'Limited-time messaging', 'IAP Revenue'),

  // BRAND / STRATEGY
  createBrief('brand_1', 'Brand', 'Positioning', 'Brand Perception Test', 'What do users think this brand is?', 'Check if brand meaning matches intent', 'Functional vs Emotional brand', 'Brand Recall'),
  createBrief('brand_2', 'Brand', 'Narrative', 'Story Resonance Test', 'Do people emotionally connect?', 'Test if the story creates any feeling', 'First-person vs Third-person', 'Watch Time'),
  createBrief('brand_3', 'Brand', 'Trust', 'Trust Signal Audit', 'Does this brand feel legit?', 'See if there’s enough proof to trust it', 'Social proof density', 'CVR'),
  createBrief('brand_4', 'Brand', 'Differentiation', 'Differentiation Test', 'Do users see how you’re different?', 'Test if differences stand out clearly', 'Direct comparison', 'Preference Lift'),
  createBrief('brand_5', 'Brand', 'Long-term', 'Brand Equity Test', 'Will people remember you later?', 'See if the brand leaves a lasting impression', 'Memory cues', 'Brand Recall'),
];

// 2. Cohort Factory
const createCohort = (
  id: string,
  category: string,
  name: string,
  description: string,
  tags: string[],
  marketStats: AS_MarketStat[],
  baseTraits: any,
  occupations: string[]
): AS_AudienceCohort => {
  const personas: AS_Persona[] = Array.from({ length: 50 }).map((_, i) => ({
    id: `p_${id}_${i}`,
    name: `User ${i}`,
    age: 22 + Math.floor(Math.random() * 35),
    gender: i % 2 === 0 ? 'Male' : 'Female',
    location: 'US/EU',
    occupation: occupations[i % occupations.length],
    education: 'Bachelor',
    socioeconomicStatus: 'Middle',
    familyStatus: 'Single',
    incomeLevel: 'Medium',
    personality: 'Simulated',
    coreValues: 'Value, Quality',
    painPoints: 'Time, Cost',
    traitFingerprint: {
      skepticism: Math.max(0, Math.min(100, baseTraits.skepticism + (Math.random() * 20 - 10))),
      innovation: Math.max(0, Math.min(100, baseTraits.innovation + (Math.random() * 20 - 10))),
      priceSensitivity: Math.max(0, Math.min(100, baseTraits.priceSensitivity + (Math.random() * 20 - 10))),
      socialProof: Math.max(0, Math.min(100, baseTraits.socialProof + (Math.random() * 20 - 10))),
      brandLoyalty: Math.max(0, Math.min(100, baseTraits.brandLoyalty + (Math.random() * 20 - 10)))
    }
  }));

  return {
    id,
    as_category: category,
    as_name: name,
    as_description: description,
    as_language: 'English',
    as_isOfficial: true,
    as_tags: tags,
    as_marketStats: marketStats,
    as_personas: personas,
    as_archetypes: generateArchetypes(category), 
    as_groupOverview: generateGroupOverview(category, 50),
    createdAt: Date.now()
  };
};

const AS_OFFICIAL_COHORTS: AS_AudienceCohort[] = [
  
  // ==================================================================================
  // 1. BEAUTY & WELLNESS
  // ==================================================================================
  createCohort('BEAUTY-01', 'Beauty & Wellness', 'Ingredient Inspector', 'Don’t sell me vibes. Tell me the key ingredients and concentrations. I’ll judge myself.', ['Transparency', 'Scientific proof'], 
    [{label:'Research Time', value:'High', trend:'up'}], 
    {skepticism:90, innovation:50, priceSensitivity:30, socialProof:20, brandLoyalty:40}, 
    ['Dermatologist', 'Chemist', 'Researcher']),
  createCohort('BEAUTY-02', 'Beauty & Wellness', 'Appearance Anxiety Rescuer', 'I have an important date tomorrow. These dark circles must go. Does it work or not?', ['Immediate effect', 'Urgency'], 
    [{label:'Urgency', value:'Extreme', trend:'stable'}], 
    {skepticism:30, innovation:60, priceSensitivity:20, socialProof:70, brandLoyalty:30}, 
    ['Student', 'Executive', 'Actor']),
  createCohort('BEAUTY-03', 'Beauty & Wellness', 'Dupe Hunter', 'Same effect — why should I pay 30% more for your brand?', ['Price–performance', 'Value'], 
    [{label:'Price Sensitivity', value:'High', trend:'up'}], 
    {skepticism:70, innovation:40, priceSensitivity:90, socialProof:60, brandLoyalty:10}, 
    ['Student', 'Analyst', 'Writer']),

  // ==================================================================================
  // 2. REAL ESTATE & HOME
  // ==================================================================================
  createCohort('HOME-01', 'Real Estate & Home', 'First-Home Buyer', 'This is five years of savings. Every square meter must be worth it.', ['Safety', 'Authority'], 
    [{label:'Decision Cycle', value:'6mo+', trend:'up'}], 
    {skepticism:80, innovation:20, priceSensitivity:70, socialProof:50, brandLoyalty:20}, 
    ['Engineer', 'Nurse', 'Accountant']),
  createCohort('HOME-02', 'Real Estate & Home', 'Lifestyle Upgrader', 'A home isn’t just for sleeping — it represents my taste.', ['Emotional value', 'Design'], 
    [{label:'Reno Budget', value:'High', trend:'stable'}], 
    {skepticism:30, innovation:70, priceSensitivity:20, socialProof:80, brandLoyalty:60}, 
    ['Designer', 'Architect', 'Creative Director']),
  createCohort('HOME-03', 'Real Estate & Home', 'Conservative Landlord', 'Don’t talk style. Tell me downside protection and rental yield.', ['Data certainty', 'ROI'], 
    [{label:'Yield Focus', value:'Max', trend:'stable'}], 
    {skepticism:60, innovation:10, priceSensitivity:30, socialProof:40, brandLoyalty:20}, 
    ['Investor', 'Business Owner', 'Manager']),

  // ==================================================================================
  // 3. AUTOMOTIVE & EV
  // ==================================================================================
  createCohort('AUTO-01', 'Automotive & EV', 'Range Anxiety Driver', 'How far does it really go in winter? How long does charging take?', ['Certainty', 'Proof'], 
    [{label:'Anxiety', value:'High', trend:'down'}], 
    {skepticism:85, innovation:40, priceSensitivity:40, socialProof:60, brandLoyalty:30}, 
    ['Sales Rep', 'Driver', 'Consultant']),
  createCohort('AUTO-02', 'Automotive & EV', 'Autonomy Geek', 'I don’t care about leather seats. Is this system smart enough?', ['Technical specs', 'Innovation'], 
    [{label:'Tech Spend', value:'High', trend:'up'}], 
    {skepticism:20, innovation:95, priceSensitivity:20, socialProof:50, brandLoyalty:40}, 
    ['Developer', 'Engineer', 'Gamer']),
  createCohort('AUTO-03', 'Automotive & EV', 'Legacy Brand Loyalist', 'I’ve driven gas cars for 10 years. Why should I give up the engine sound?', ['Emotional trust', 'Tradition'], 
    [{label:'Switch Cost', value:'High', trend:'stable'}], 
    {skepticism:70, innovation:10, priceSensitivity:50, socialProof:40, brandLoyalty:90}, 
    ['Mechanic', 'Tradesperson', 'Manager']),

  // ==================================================================================
  // 4. EDUCATION & COACHING
  // ==================================================================================
  createCohort('EDU-01', 'Education & Coaching', 'Side-Hustle Dreamer', 'Can this course actually help me make money?', ['Monetization', 'ROI'], 
    [{label:'ROI Expectation', value:'Immediate', trend:'up'}], 
    {skepticism:50, innovation:60, priceSensitivity:40, socialProof:80, brandLoyalty:20}, 
    ['Clerk', 'Student', 'Freelancer']),
  createCohort('EDU-02', 'Education & Coaching', 'Burned-Out Parent', 'Everyone else is buying it. I can’t let my kid fall behind.', ['FOMO', 'Peace of mind'], 
    [{label:'Willingness to Pay', value:'High', trend:'stable'}], 
    {skepticism:40, innovation:30, priceSensitivity:20, socialProof:90, brandLoyalty:50}, 
    ['Teacher', 'Parent', 'Admin']),
  createCohort('EDU-03', 'Education & Coaching', 'Lifelong Learner', 'I want a complete framework, not fragmented tips.', ['Professional depth', 'Structure'], 
    [{label:'Completion Rate', value:'High', trend:'stable'}], 
    {skepticism:60, innovation:50, priceSensitivity:40, socialProof:30, brandLoyalty:60}, 
    ['Engineer', 'Researcher', 'Academic']),

  // ==================================================================================
  // 5. F&B & SERVICES
  // ==================================================================================
  createCohort('FOOD-01', 'F&B & Services', 'Check-In Influencer', 'Taste is secondary. Does it look good in photos?', ['Shareability', 'Visuals'], 
    [{label:'Share Rate', value:'Max', trend:'up'}], 
    {skepticism:20, innovation:80, priceSensitivity:30, socialProof:95, brandLoyalty:20}, 
    ['Influencer', 'Student', 'Designer']),
  createCohort('FOOD-02', 'F&B & Services', 'Queue Validator', 'So many people are lining up — there must be a reason.', ['Herd signals', 'Credibility'], 
    [{label:'Risk Tolerance', value:'Low', trend:'stable'}], 
    {skepticism:40, innovation:20, priceSensitivity:50, socialProof:90, brandLoyalty:40}, 
    ['Tourist', 'Student', 'Office Worker']),
  createCohort('FOOD-03', 'F&B & Services', 'Value Office Worker', '15-minute delivery, big portions. Don’t sell me chef passion.', ['Time', 'Cost'], 
    [{label:'Time Sensitivity', value:'Extreme', trend:'up'}], 
    {skepticism:30, innovation:50, priceSensitivity:60, socialProof:30, brandLoyalty:50}, 
    ['Delivery Driver', 'Coder', 'Analyst']),

  // ==================================================================================
  // 6. GEN-Z & SUBCULTURE
  // ==================================================================================
  createCohort('GENZ-01', 'Gen-Z & Subculture', 'Anti-Ad Native', 'If it’s boring in three seconds, I swipe away.', ['Instant stim', 'Hooks'], 
    [{label:'Attn Span', value:'Short', trend:'down'}], 
    {skepticism:80, innovation:90, priceSensitivity:50, socialProof:40, brandLoyalty:20}, 
    ['Creator', 'Student', 'Artist']),
  createCohort('GENZ-02', 'Gen-Z & Subculture', 'Subculture Gatekeeper', 'If you don’t get our codes, don’t talk to us.', ['Cultural correctness', 'Identity'], 
    [{label:'Engagement', value:'High', trend:'stable'}], 
    {skepticism:60, innovation:40, priceSensitivity:30, socialProof:90, brandLoyalty:80}, 
    ['Gamer', 'Mod', 'Fan']),

  // ==================================================================================
  // 7. MODERN MOMS
  // ==================================================================================
  createCohort('MOM-01', 'Modern Moms & Decision Makers', 'Expert Mom', 'I’ll check every ingredient myself. I trust reviews, not hype.', ['Authority', 'Word of mouth'], 
    [{label:'Trust Threshold', value:'High', trend:'up'}], 
    {skepticism:90, innovation:20, priceSensitivity:30, socialProof:80, brandLoyalty:60}, 
    ['Nurse', 'Teacher', 'Manager']),
  createCohort('MOM-02', 'Modern Moms & Decision Makers', 'Anxiety-Driven Mom', 'Tell me what problem this solves for my child — now.', ['Anxiety relief', 'Precision'], 
    [{label:'Spend', value:'High', trend:'up'}], 
    {skepticism:30, innovation:50, priceSensitivity:20, socialProof:95, brandLoyalty:40}, 
    ['Parent', 'Admin', 'Freelancer']),

  // ==================================================================================
  // 8. FITNESS & HEALTH
  // ==================================================================================
  createCohort('FIT-01', 'Fitness & Health Enthusiasts', 'Data-Only Lifter', 'Heart rate, body fat, calories — how much will this improve my data?', ['Metric improvement', 'Function'], 
    [{label:'Retention', value:'High', trend:'stable'}], 
    {skepticism:40, innovation:70, priceSensitivity:30, socialProof:40, brandLoyalty:50}, 
    ['Trainer', 'Engineer', 'Athlete']),
  createCohort('FIT-02', 'Fitness & Health Enthusiasts', 'Lifestyle Athlete', 'It has to work and look good.', ['Emotion', 'Aesthetics'], 
    [{label:'Gear Spend', value:'High', trend:'up'}], 
    {skepticism:20, innovation:80, priceSensitivity:40, socialProof:80, brandLoyalty:60}, 
    ['Designer', 'Marketer', 'Student']),

  // ==================================================================================
  // 9. WORKFORCE DYNAMICS
  // ==================================================================================
  createCohort('WORK-01', 'Workforce Dynamics', 'Productivity Maximalist', 'If it lets me leave work earlier, I’m in.', ['Efficiency gain', 'Function'], 
    [{label:'Willingness to Pay', value:'Med', trend:'up'}], 
    {skepticism:50, innovation:80, priceSensitivity:40, socialProof:50, brandLoyalty:30}, 
    ['Developer', 'Founder', 'Manager']),
  createCohort('WORK-02', 'Workforce Dynamics', 'Self-Reward Worker', 'I’m exhausted. Spending a bit to feel good is fair.', ['Emotional value', 'Satisfaction'], 
    [{label:'Micro-Trans', value:'High', trend:'up'}], 
    {skepticism:20, innovation:50, priceSensitivity:60, socialProof:60, brandLoyalty:40}, 
    ['Clerk', 'Service Worker', 'Junior Staff']),
];
