
import { AS_AudienceCohort, AS_SimulationSnapshot, MB_MasterBrief, ExperimentOption } from '../types';
import { AS_getCohorts, AS_saveCohort, AS_deleteCohort } from './storageService';

export class AS_SimulatorEngine {
  
  static getAllCohorts(): AS_AudienceCohort[] {
    return AS_getCohorts();
  }

  // --- CRITICAL: THE "EXPORT" BRIDGE ---
  // Converts a live Master Brief (Module A) into a frozen Simulation Snapshot (Module B)
  static createSnapshotFromBrief(brief: MB_MasterBrief): AS_SimulationSnapshot {
    return {
      sourceBriefId: brief.id,
      frozenTitle: brief.mb_title,
      frozenContent: brief.mb_content,
      frozenImages: brief.mb_images || []
    };
  }

  static createComparisonSnapshot(briefs: MB_MasterBrief[]): AS_SimulationSnapshot {
    const options: ExperimentOption[] = briefs.map(b => ({
      id: b.id,
      title: b.mb_title,
      description: b.mb_content,
      image: b.mb_images?.[0]
    }));

    return {
      sourceBriefId: 'multi',
      frozenTitle: `Comparison: ${briefs.length} Briefs`,
      frozenContent: 'Comparative Analysis',
      frozenImages: [],
      options: options
    };
  }

  static saveCohort(cohort: AS_AudienceCohort) {
    AS_saveCohort(cohort);
  }

  static deleteCohort(id: string) {
    AS_deleteCohort(id);
  }
}
