
import { GoogleGenAI, Type, Schema, GenerateContentParameters } from "@google/genai";
import { 
  AS_Persona, AnalysisResult, ExperimentOption, ExperimentType, 
  UniversalDashboardData, AS_SimulationSnapshot, AS_AudienceCohort, 
  AS_CohortArchetype, AS_GroupOverview, AS_MotherPopulationConfig, AS_Nuwa_Radar
} from "../types";

// --- SYSTEM PROMPTS (ISOLATED) ---

const NUWA_SYSTEM_PROMPT = `
ROLE: Nuwa Generation Engine (Module C)
CONTEXT: You are a "Cognitive Psychologist" AI. You receive "Skeletons" (raw demographic data) and breathe life into them by inferring their psychological state.
INPUT: A JSON list of user skeletons (Age, Job, Education, Base Traits) AND an optional "SPECIAL INSTRUCTION".
TASK: For EACH skeleton, generate:
1. "nuwa_radar": 4 Commercial Personality scores (0-100):
   - PAT: Patience (Tolerance for friction/long copy). High = Reads details. Low = Skims/Bounces.
   - LOG: Logic (Reliance on specs/data vs vibes). High = Needs proof. Low = Buys on emotion.
   - IMP: Impulse (Likelihood to buy now). High = FOMO driven. Low = Deliberate/Wait.
   - BUD: Budget Sensitivity (Pain of paying). High = Price hunter. Low = Premium buyer.
2. "nuwa_mindset": A 1-sentence "Mental Snapshot" (e.g., "Overworked lawyer looking for quick wins").
3. "nuwa_innerMonologue": A typical thought they might have when browsing (e.g., "Is this just another scam?").
4. "name": A realistic name fitting their demographic.

PRINCIPLE: Non-Linear Inference.
- A "Lawyer" (High LOG) might have Low PAT (busy).
- A "Student" (Low BUD) might have High IMP (trends).
- IF "SPECIAL INSTRUCTION" is provided, apply that bias to ALL profiles (e.g. "Make them all skeptics").
`;

const AS_SYSTEM_PROMPT = `
ROLE: Audience Simulator Engine (Module B)
CONTEXT: You simulate 50 unique human personas to stress-test business directives.
PRINCIPLES:
1. Empathy: Fully embody the provided persona (Age, Job, Trait Fingerprint).
2. Authenticity: If the persona is "Skeptic", they MUST doubt the claims. If "Price Sensitive", they MUST complain about cost.
3. Unidirectional: You only react to the provided Snapshot. Do not invent external context.
`;

const CONFIG_RECOMMENDER_PROMPT = `
ROLE: Population Architect.
TASK: Convert a natural language description (or raw text) of a target audience into specific demographic and psychographic configuration settings.
OUTPUT: A JSON object matching the schema.
RULES:
1. 'genderRatio': 0 = All Female, 1 = All Male, 0.5 = Balanced.
2. 'ageRange': [min, max].
3. Distributions (income, vocation, education): Return 3-5 categories with weights summing to exactly 100.
4. 'traits': 3-5 succinct adjectives.
5. 'decisionMotive': Pick one dominant driver (e.g. "Risk Aversion", "Status Seeking", "Efficiency").
6. 'customInstruction': Write a concise directive for the persona generator that summarizes the specific behavioral characteristics or biases of this group (e.g., "They should be highly skeptical of marketing", "Make them enthusiastic early adopters").
`;

// --- SCHEMAS ---

const RECOMMENDATION_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "A short, professional name for this cohort" },
    description: { type: Type.STRING, description: "A 1-sentence summary of who these people are" },
    customInstruction: { type: Type.STRING, description: "A directive summarizing the specific behavioral characteristics." },
    genderRatio: { type: Type.NUMBER, description: "0.0 to 1.0" },
    ageRange: { 
      type: Type.ARRAY, 
      items: { type: Type.INTEGER },
      description: "[min, max]"
    },
    traits: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING } 
    },
    decisionMotive: { type: Type.STRING },
    incomeDist: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          weight: { type: Type.INTEGER }
        },
        required: ["label", "weight"]
      }
    },
    vocationDist: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          weight: { type: Type.INTEGER }
        },
        required: ["label", "weight"]
      }
    },
    educationDist: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          weight: { type: Type.INTEGER }
        },
        required: ["label", "weight"]
      }
    }
  },
  required: ["title", "description", "customInstruction", "genderRatio", "ageRange", "traits", "decisionMotive", "incomeDist", "vocationDist", "educationDist"]
};

const NUWA_ENRICHMENT_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    profiles: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          tempId: { type: Type.STRING },
          name: { type: Type.STRING },
          nuwa_mindset: { type: Type.STRING },
          nuwa_innerMonologue: { type: Type.STRING },
          nuwa_radar: {
            type: Type.OBJECT,
            properties: {
              PAT: { type: Type.INTEGER },
              LOG: { type: Type.INTEGER },
              IMP: { type: Type.INTEGER },
              BUD: { type: Type.INTEGER }
            },
            required: ["PAT", "LOG", "IMP", "BUD"]
          }
        },
        required: ["tempId", "name", "nuwa_mindset", "nuwa_radar", "nuwa_innerMonologue"]
      }
    }
  }
};

const AS_ANALYSIS_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    confidenceScore: { type: Type.INTEGER },
    results: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          personaId: { type: Type.STRING },
          sentiment: { type: Type.STRING, enum: ["Positive", "Neutral", "Negative"] },
          score: { type: Type.INTEGER },
          selectedOptionId: { type: Type.STRING },
          reaction: { type: Type.STRING },
          keyConcernOrPraise: { type: Type.STRING },
          purchaseIntent: { type: Type.STRING, enum: ["High", "Medium", "Low", "None"] },
          landingPageMetrics: {
             type: Type.OBJECT,
             nullable: true,
             properties: {
                bounced: { type: Type.BOOLEAN },
                scrollDepth: { type: Type.INTEGER },
                timeOnPage: { type: Type.INTEGER },
                clickedCTA: { type: Type.BOOLEAN },
                converted: { type: Type.BOOLEAN }
             },
             required: ["bounced", "scrollDepth", "timeOnPage", "clickedCTA", "converted"]
          }
        },
        required: ["personaId", "sentiment", "score", "reaction", "keyConcernOrPraise", "purchaseIntent"]
      }
    }
  }
};

// --- HELPERS ---

const callGeminiWithRetry = async (
  options: GenerateContentParameters,
  retries: number = 2
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  for (let i = 0; i <= retries; i++) {
    try {
      return await ai.models.generateContent(options);
    } catch (error: any) {
      console.error(`Gemini Attempt ${i+1} Failed:`, error);
      if (i < retries) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        continue;
      }
      throw error;
    }
  }
  throw new Error("Max retries exceeded");
};

const parseJSON = (text?: string) => {
  if (!text) return {};
  let clean = text.trim();
  if (clean.startsWith('```json')) clean = clean.replace(/^```json/, '').replace(/```$/, '');
  else if (clean.startsWith('```')) clean = clean.replace(/^```/, '').replace(/```$/, '');
  try {
    return JSON.parse(clean);
  } catch (e) {
    console.error("JSON Parse Error. Raw text:", text);
    return {};
  }
};

// --- NUWA ENGINE LOGIC (Step 0: The Architect - Mother Config) ---

export const AS_Nuwa_recommendConfig = async (userInput: string): Promise<Partial<AS_MotherPopulationConfig>> => {
  try {
    const response = await callGeminiWithRetry({
      model: 'gemini-3-flash-preview',
      contents: [{ parts: [{ text: CONFIG_RECOMMENDER_PROMPT + "\n\nUSER DESCRIPTION:\n" + userInput }] }],
      config: { 
        responseMimeType: 'application/json', 
        responseSchema: RECOMMENDATION_SCHEMA 
      }
    });
    
    const data = parseJSON(response.text);
    // Basic validation to ensure ranges are safe
    if (data.ageRange && data.ageRange.length === 2) {
       data.ageRange = [Math.max(18, data.ageRange[0]), Math.min(90, data.ageRange[1])];
    }
    return data;
  } catch (e) {
    console.error("Config Recommendation Failed:", e);
    return {};
  }
};

// --- NUWA ENGINE LOGIC (Step 1: The Skeleton Crew - Local Math) ---

const weightedRandom = (items: { label: string; weight: number }[]): string => {
  const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
  let random = Math.random() * totalWeight;
  for (const item of items) {
    if (random < item.weight) return item.label;
    random -= item.weight;
  }
  return items[0].label;
};

// Generates statistically accurate "Empty Shells" locally to avoid AI hallucinating distributions
const generateSkeletons = (config: AS_MotherPopulationConfig, count: number): Partial<AS_Persona>[] => {
  const skeletons: Partial<AS_Persona>[] = [];
  
  for (let i = 0; i < count; i++) {
    // 1. Gender (Strict Ratio)
    const isMale = Math.random() < config.genderRatio;
    const gender = isMale ? 'Male' : 'Female';

    // 2. Age (Gaussian-ish distribution within range)
    const [minAge, maxAge] = config.ageRange;
    // Box-Muller transform for normal distribution
    let u = 0, v = 0;
    while(u === 0) u = Math.random(); 
    while(v === 0) v = Math.random();
    let num = Math.sqrt( -2.0 * Math.log( u ) ) * Math.cos( 2.0 * Math.PI * v );
    num = num / 10.0 + 0.5; // Translate to 0 -> 1 centered
    if (num > 1 || num < 0) num = Math.random(); // Fallback to flat random
    const age = Math.floor(minAge + (maxAge - minAge) * num);

    // 3. Distributions (Weighted Random)
    const occupation = weightedRandom(config.vocationDist);
    const income = weightedRandom(config.incomeDist);
    const education = weightedRandom(config.educationDist);

    skeletons.push({
      id: `temp_${i}`, // Temporary ID for mapping
      gender,
      age,
      occupation,
      incomeLevel: income,
      education,
      location: 'Tier 1 City', // Default for now, could be config
      coreValues: config.decisionMotive,
      personality: config.traits.join(', '),
      familyStatus: age < 25 ? 'Single' : age < 35 ? 'Married' : 'Parent' // Simple inference
    });
  }
  
  return skeletons;
};

// --- NUWA ENGINE LOGIC (Step 2: The Soul Injection - AI Enrichment) ---

export const AS_Nuwa_generatePersonas = async (
  config: AS_MotherPopulationConfig, 
  count: number = 50,
  onProgress?: (progress: number) => void
): Promise<AS_AudienceCohort> => {
  
  // Phase 1: Census (Local Math) - Creates the Demographics
  if (onProgress) onProgress(10);
  const skeletons = generateSkeletons(config, count);
  if (onProgress) onProgress(30);

  // Phase 2: Enrichment (Batch AI) - Creates the Psychographics
  // We send skeletons in batches to Gemini to get the psychological layer
  const BATCH_SIZE = 10;
  const enrichedPersonas: AS_Persona[] = [];

  for (let i = 0; i < skeletons.length; i += BATCH_SIZE) {
    const batch = skeletons.slice(i, i + BATCH_SIZE);
    
    // The prompt links the specific demographics of the skeleton to the mother config context
    const prompt = `
    Analyze these ${batch.length} skeletons and generate their psychological profiles.
    MOTHER CONTEXT: ${config.description}
    TRAITS: ${config.traits.join(', ')}
    MOTIVE: ${config.decisionMotive}
    
    SPECIAL INSTRUCTION (CRITICAL): ${config.customInstruction || "None"}

    SKELETONS:
    ${JSON.stringify(batch.map(s => ({ 
       tempId: s.id, 
       desc: `${s.age}yo ${s.gender} ${s.occupation}, Income: ${s.incomeLevel}, Edu: ${s.education}` 
    })))}
    `;

    try {
        const response = await callGeminiWithRetry({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: NUWA_SYSTEM_PROMPT + "\n" + prompt }] }],
        config: { responseMimeType: 'application/json', responseSchema: NUWA_ENRICHMENT_SCHEMA }
        });

        const output = parseJSON(response.text);
        
        // Merge AI output with Skeletons
        if (output.profiles) {
        output.profiles.forEach((aiProfile: any) => {
            const skeleton = batch.find(s => s.id === aiProfile.tempId);
            if (skeleton) {
            enrichedPersonas.push({
                ...skeleton,
                id: `p_${Date.now()}_${enrichedPersonas.length}`, // Final ID
                name: aiProfile.name,
                nuwa_mindset: aiProfile.nuwa_mindset,
                nuwa_innerMonologue: aiProfile.nuwa_innerMonologue,
                nuwa_radar: aiProfile.nuwa_radar,
                // Backwards compatibility mapping for legacy templates
                traitFingerprint: {
                    skepticism: 100 - aiProfile.nuwa_radar.PAT, // Low patience ~ High skepticism
                    innovation: aiProfile.nuwa_radar.IMP,
                    priceSensitivity: aiProfile.nuwa_radar.BUD,
                    socialProof: 50, 
                    brandLoyalty: 50 
                }
            } as AS_Persona);
            }
        });
        }
    } catch (err) {
        console.error("Batch enrichment failed, using fallbacks for batch", err);
        // Fallback: use skeletons with generic data so we don't crash
        batch.forEach(skel => {
             enrichedPersonas.push({
                ...skel,
                id: `p_${Date.now()}_${enrichedPersonas.length}`,
                name: `User ${skel.id}`,
                nuwa_mindset: "Generic Profile (AI Error)",
                nuwa_innerMonologue: "...",
                nuwa_radar: { PAT: 50, LOG: 50, IMP: 50, BUD: 50 },
                traitFingerprint: { skepticism: 50, innovation: 50, priceSensitivity: 50, socialProof: 50, brandLoyalty: 50 }
             } as AS_Persona);
        });
    }
    
    if (onProgress) onProgress(30 + Math.floor(((i + BATCH_SIZE) / count) * 60));
  }

  // Phase 3: Final Assembly
  const cohort: AS_AudienceCohort = {
    id: config.id,
    as_name: config.title,
    as_description: config.description,
    as_category: "Custom",
    as_tags: config.tags,
    as_language: 'English',
    as_personas: enrichedPersonas,
    // Generate simple averages for group overview for the UI
    as_groupOverview: {
       totalUsers: count,
       characteristics: `Generated via Nuwa Engine based on: ${config.title}. ${config.customInstruction ? `Note: ${config.customInstruction}` : ''}`,
       distribution: { happyPath: 20, baseline: 60, stressTest: 20 },
       visualHint: `Pat: Avg, Log: Avg`
    },
    as_archetypes: [], // Can be filled if needed
    createdAt: Date.now()
  };

  if (onProgress) onProgress(100);
  return cohort;
};

// --- LEGACY EXPORTS (Maintaining compatibility) ---

export const AS_runSimulation = async (
  personas: AS_Persona[],
  type: ExperimentType,
  snapshot: AS_SimulationSnapshot,
  templateId: string,
  language: string,
  onProgress: (progress: number) => void
): Promise<{
  results: AnalysisResult[];
  confidenceScore: number;
  structuredInsights: any;
  summary: string;
  actionItems: string[];
}> => {
  
  const BATCH_SIZE = 5;
  const allResults: AnalysisResult[] = [];
  let totalConfidence = 0;

  const inputText = type === 'VALIDATION' 
      ? `DIRECTIVE: "${snapshot.frozenContent}" (Title: ${snapshot.frozenTitle})`
      : `COMPARISON: ${snapshot.options?.map(o => `[${o.id}] ${o.title}: ${o.description}`).join(' vs ')}`;

  for (let i = 0; i < personas.length; i += BATCH_SIZE) {
    const batch = personas.slice(i, i + BATCH_SIZE);
    
    // Updated prompt to use NUWA fields if available
    const userPrompt = `
    TASK: Simulate reaction of these ${batch.length} users.
    INPUT: ${inputText}
    USERS: ${JSON.stringify(batch.map(p => ({ 
       id: p.id, 
       name: p.name, 
       desc: p.nuwa_mindset || p.personality, // Use Mindset if available
       dna: p.nuwa_radar || p.traitFingerprint // Use Radar if available
    })))}
    OUTPUT: JSON array of results.
    Language: ${language}
    `;

    const response = await callGeminiWithRetry({
      model: 'gemini-3-flash-preview',
      contents: [{ parts: [{ text: AS_SYSTEM_PROMPT + "\n" + userPrompt }] }],
      config: {
        responseMimeType: 'application/json',
        responseSchema: AS_ANALYSIS_SCHEMA,
      }
    });

    const data = parseJSON(response.text);
    if (data.results) allResults.push(...data.results);
    if (data.confidenceScore) totalConfidence += data.confidenceScore;

    onProgress(((i + BATCH_SIZE) / personas.length) * 80);
  }

  const avgConfidence = Math.round(totalConfidence / Math.ceil(personas.length / BATCH_SIZE)) || 85;
  
  // Aggregation Step
  onProgress(90);
  const aggPrompt = `
  Analyze results from ${personas.length} personas.
  TYPE: ${type}
  TEMPLATE: ${templateId}
  INPUT: ${inputText}
  RESULTS SAMPLE: ${JSON.stringify(allResults.slice(0, 20))}...
  Generate comprehensive dashboard JSON.
  Language: ${language}
  `;

  const aggResponse = await callGeminiWithRetry({
      model: 'gemini-3-flash-preview',
      contents: [{ parts: [{ text: AS_SYSTEM_PROMPT + "\n" + aggPrompt }] }],
      config: { responseMimeType: 'application/json' }
  });

  const aggData = parseJSON(aggResponse.text);
  onProgress(100);

  return {
    results: allResults,
    confidenceScore: avgConfidence,
    structuredInsights: aggData,
    summary: aggData.summary || "Analysis complete.",
    actionItems: aggData.actions?.map((a: any) => a.label) || []
  };
};

// Keep for legacy calls but point to new logic if possible
export const AS_builder_analyzeIntent = async (userInput: string): Promise<any> => { return {}; }; 
export const AS_builder_nextQuestion = async (h: any, t: any, s: number): Promise<any> => { return {}; };
export const AS_builder_finalize = async (s: string, t: any, c: string): Promise<any> => { return {}; };
export const AS_generatePersonas = async (d: string, l: string): Promise<AS_Persona[]> => { return []; };
