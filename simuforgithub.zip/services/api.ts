
import { User, Session, MB_MasterBrief, AS_AudienceCohort, Article, PaymentTransaction, PlanLevel, COST_TABLE, PLAN_LIMITS } from '../types';
import * as Storage from './storageService';
import { MB_BriefManager } from './MB_BriefManager';
import { AS_SimulatorEngine } from './AS_SimulatorEngine';

/**
 * API SERVICE LAYER (Business Logic Enforcer)
 * This mimics the backend controller logic defined in the PDD.
 */

const LATENCY = 300; 
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

// Mock Database State (In-memory for session, sync with storage)
let currentUser: User | null = null;

export const api = {
  
  auth: {
    login: async (email: string): Promise<User> => {
      await delay(LATENCY);
      // PDD R-CREDIT-01: Free user gets 20 credits initially
      currentUser = { 
        id: 'u1', 
        name: 'Demo User', 
        email: email, 
        avatar: 'https://ui-avatars.com/api/?name=Demo+User&background=ea580c&color=fff', 
        points: 20, 
        plan_level: 'FREE',
        subscription_status: 'active'
      };
      return currentUser;
    },
    
    // Internal use to get fresh user state
    getCurrentUser: () => currentUser,

    updateUserPlan: async (plan: PlanLevel, credits: number): Promise<User> => {
      await delay(LATENCY);
      if (!currentUser) throw new Error("Not logged in");
      
      currentUser = {
         ...currentUser,
         plan_level: plan,
         points: currentUser.points + credits // Top-up logic
      };
      return currentUser;
    },

    deductCredits: async (amount: number): Promise<User> => {
       await delay(100); // Fast check
       if (!currentUser) throw new Error("Not logged in");
       if (currentUser.points < amount) {
          throw new Error("INSUFFICIENT_FUNDS");
       }
       currentUser = { ...currentUser, points: currentUser.points - amount };
       return currentUser;
    }
  },

  payment: {
    processPayPalOrder: async (orderId: string, planId: string): Promise<PaymentTransaction> => {
       await delay(LATENCY + 1000); 
       // PDD Pricing: Pro = $99, Pro+ = $199
       return {
          id: orderId,
          amount: planId === 'PRO_PLUS' ? 199 : 99,
          currency: 'USD',
          status: 'COMPLETED',
          planId: planId,
          createdAt: Date.now()
       };
    }
  },

  sessions: {
    list: async (): Promise<Session[]> => {
      await delay(LATENCY);
      return Storage.getSessions();
    },
    // KUAFU ENGINE TRIGGER
    create: async (session: Session): Promise<Session> => {
      // PDD R-BIZ-02: Deduct 10 credits for Experiment
      await api.auth.deductCredits(COST_TABLE.RUN_SIMULATION);
      
      await delay(LATENCY);
      Storage.saveSession(session);
      return session;
    },
    update: async (session: Session): Promise<Session> => {
      await delay(200);
      Storage.saveSession(session);
      return session;
    },
    delete: async (id: string): Promise<void> => {
      await delay(LATENCY);
      Storage.deleteSession(id);
    }
  },

  assets: {
    briefs: {
      list: async (): Promise<MB_MasterBrief[]> => {
        await delay(LATENCY);
        return MB_BriefManager.getAll();
      },
      save: async (brief: MB_MasterBrief): Promise<void> => {
        // PDD R-BIZ-03: Check Brief Limits
        // Free: 1, Pro: 20, Pro+: 100
        if (!currentUser) throw new Error("User not found");
        
        const currentBriefs = MB_BriefManager.getAll();
        const isNew = !currentBriefs.find(b => b.id === brief.id);
        const limit = PLAN_LIMITS[currentUser.plan_level].maxBriefs;

        // Note: In a real DB, we'd query count(*) where tenant_id = X
        if (isNew && currentBriefs.length >= limit) {
           throw new Error(`PLAN_LIMIT_REACHED: Max ${limit} briefs for ${currentUser.plan_level} plan.`);
        }

        await delay(200);
        MB_BriefManager.update(brief, {});
      },
      delete: async (id: string): Promise<void> => {
        await delay(LATENCY);
        MB_BriefManager.delete(id);
      }
    },
    cohorts: {
      list: async (): Promise<AS_AudienceCohort[]> => {
        await delay(LATENCY);
        return AS_SimulatorEngine.getAllCohorts();
      },
      // NUWA ENGINE TRIGGER
      save: async (cohort: AS_AudienceCohort): Promise<void> => {
         // PDD R-BIZ-01: Deduct 5 credits for Cohort Creation
         // Check if it's a new cohort (simple check by ID existence in local storage)
         const existing = AS_SimulatorEngine.getAllCohorts().find(c => c.id === cohort.id);
         if (!existing) {
            await api.auth.deductCredits(COST_TABLE.CREATE_COHORT);
         }

         await delay(200);
         AS_SimulatorEngine.saveCohort(cohort);
      },
      delete: async (id: string): Promise<void> => {
         await delay(LATENCY);
         AS_SimulatorEngine.deleteCohort(id);
      }
    }
  },

  community: {
    getArticles: async (): Promise<Article[]> => {
       await delay(LATENCY);
       return Storage.getArticles();
    }
  }
};
